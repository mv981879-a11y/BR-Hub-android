# BR Hub — Android / Capacitor

App Android offline basada en el dashboard BR Hub. El código web, el manifiesto y los recursos fuente de icono viven en `web/`. El workflow genera la plataforma nativa Android en GitHub Actions cuando `android/` no está en el repositorio.

## Subir a GitHub desde el celular

Puedes omitir la carpeta `android/`: no es necesario subirla. Sube el resto del contenido del proyecto a la raíz del repositorio, especialmente `.github/workflows/android-debug.yml`, `web/`, `scripts/`, `package.json`, `package-lock.json` y `capacitor.config.json`. El workflow ejecuta `npm run cap:sync`, que crea Android con Capacitor si falta, sincroniza la app y restaura el manifiesto e iconos de BR Hub.

Si GitHub no te deja subir la carpeta oculta `.github`, créala con **Add file → Create new file** usando como nombre `.github/workflows/android-debug.yml` y pega el workflow incluido en este proyecto.

## Compilar localmente

Requisitos: Node.js 22 o superior, Java 21 y Android SDK Platform 36 con Build Tools 36.0.0.

```bash
npm ci
npm run android:debug
```

El APK debug queda en `android/app/build/outputs/apk/debug/app-debug.apk`. No es un APK firmado para publicación en Google Play.

## GitHub Actions

El workflow `.github/workflows/android-debug.yml` se ejecuta al hacer push o pull request a `main`/`master`, y también puede iniciarse desde **Actions → Android debug APK → Run workflow**. Al terminar, abre la ejecución y descarga el artifact **`br-hub-debug-apk`** (disponible durante 14 días).

No requiere secretos de firma ni credenciales.

## Iconos y manifiestos

- `web/manifest.webmanifest`: manifiesto web para modo standalone y orientación vertical.
- `web/icons/br-hub.svg`: icono vectorial local, sin imágenes externas.
- `web/icons/android/`: foreground vectorial y variantes PNG de lanzador derivadas del diseño BR Hub, copiadas al proyecto Android durante `npm run cap:sync`.
- `capacitor.config.json`: identificador `com.brhub.mobile` y nombre de app.
- `scripts/prepare-android.mjs`: configura el manifiesto nativo con orientación vertical y permisos offline, además de los iconos adaptativos.

Los ajustes se guardan en `localStorage` de la WebView. La app no carga recursos remotos ni solicita permiso de Internet en el manifiesto nativo.
