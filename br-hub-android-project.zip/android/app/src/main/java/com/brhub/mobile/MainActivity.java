package com.brhub.mobile;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
