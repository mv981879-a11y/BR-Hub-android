import { existsSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const androidDir = resolve(root, 'android');

if (existsSync(androidDir)) {
  console.log('Android platform already exists; keeping the supplied project.');
  process.exit(0);
}

console.log('Android platform is missing; generating it with Capacitor.');
const command = process.platform === 'win32' ? 'npx.cmd' : 'npx';
const result = spawnSync(command, ['cap', 'add', 'android'], {
  cwd: root,
  stdio: 'inherit'
});

if (result.error) throw result.error;
if (result.status !== 0) process.exit(result.status ?? 1);
