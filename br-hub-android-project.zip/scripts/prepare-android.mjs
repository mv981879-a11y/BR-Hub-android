import { copyFile, mkdir, readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const native = resolve(root, 'android/app/src/main');
const manifestPath = resolve(native, 'AndroidManifest.xml');

let manifest = await readFile(manifestPath, 'utf8');
manifest = manifest.replace(/android:icon="[^"]+"/, 'android:icon="@mipmap/ic_launcher"');
manifest = manifest.replace(/android:roundIcon="[^"]+"/, 'android:roundIcon="@mipmap/ic_launcher_round"');
if (/android:screenOrientation="[^"]+"/.test(manifest)) {
  manifest = manifest.replace(/android:screenOrientation="[^"]+"/, 'android:screenOrientation="portrait"');
} else {
  manifest = manifest.replace(/<activity\b/, '<activity\n            android:screenOrientation="portrait"');
}
manifest = manifest.replace(/\s*<uses-permission\s+android:name="android\.permission\.INTERNET"\s*\/>/g, '');
await writeFile(manifestPath, manifest);

const resources = resolve(native, 'res');
const assetIcons = resolve(root, 'web/icons/android');
const foregroundXml = await readFile(resolve(assetIcons, 'ic_launcher_foreground.xml'), 'utf8');

const foregroundDir = resolve(resources, 'drawable-v24');
await mkdir(foregroundDir, { recursive: true });
await writeFile(resolve(foregroundDir, 'ic_launcher_foreground.xml'), foregroundXml);

const colorDir = resolve(resources, 'values');
await mkdir(colorDir, { recursive: true });
await writeFile(resolve(colorDir, 'ic_launcher_background.xml'), `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#0D0D0F</color>\n</resources>\n`);

const adaptiveDir = resolve(resources, 'mipmap-anydpi-v26');
await mkdir(adaptiveDir, { recursive: true });
for (const name of ['ic_launcher.xml', 'ic_launcher_round.xml']) {
  await writeFile(resolve(adaptiveDir, name), `<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n    <background android:drawable="@color/ic_launcher_background" />\n    <foreground android:drawable="@drawable/ic_launcher_foreground" />\n</adaptive-icon>\n`);
}

for (const density of ['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi']) {
  const target = resolve(resources, `mipmap-${density}`);
  await mkdir(target, { recursive: true });
  for (const name of ['ic_launcher.png', 'ic_launcher_round.png']) {
    await copyFile(resolve(assetIcons, `mipmap-${density}`, name), resolve(target, name));
  }
}

console.log('BR Hub Android manifest, offline policy and launcher icons prepared.');
